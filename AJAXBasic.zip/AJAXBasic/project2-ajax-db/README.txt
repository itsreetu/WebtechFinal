PROJECT 2 - Simple Form + Database + AJAX (live "Already exist" check)
=========================================================================

FILES:
config.php     -> database connection
index.php      -> form + saves data + AJAX script
check_name.php -> AJAX endpoint, checks Name column, called on every keystroke
database.sql   -> creates database + table

SETUP (phpMyAdmin):
1. Go to http://localhost/phpmyadmin
2. Click "Import" tab -> choose "database.sql" -> click "Go"
   (this creates database "simple_db_ajax" and table "people" automatically)

TABLE STRUCTURE (3 columns):
   id         INT, Auto Increment, Primary Key
   name       VARCHAR(100)
   id_number  VARCHAR(50)

RUN:
1. Copy this folder into htdocs (e.g. C:\xampp\htdocs\project2-ajax-db)
2. Start Apache + MySQL in XAMPP
3. Open http://localhost/project2-ajax-db/index.php
4. Register a Name once (e.g. "John"), click Submit.
5. Type "John" again in the Name field - as you type each letter,
   "Already exist" appears automatically once the full match is found
   in the database (no page reload, this is AJAX in action).
