PROJECT 1 - Simple Form + Database (no AJAX)
==============================================

FILES:
config.php   -> database connection
index.php    -> form + saves data to database
database.sql -> creates database + table

SETUP (phpMyAdmin):
1. Go to http://localhost/phpmyadmin
2. Click "New" (left sidebar)
3. OR simply click "Import" tab -> choose "database.sql" -> click "Go"
   (this creates database "simple_db" and table "people" automatically)

TABLE STRUCTURE (2 real fields, 3 columns):
   id         INT, Auto Increment, Primary Key
   name       VARCHAR(100)
   id_number  VARCHAR(50)

RUN:
1. Copy this folder into htdocs (e.g. C:\xampp\htdocs\project1-simple-db)
2. Start Apache + MySQL in XAMPP
3. Open http://localhost/project1-simple-db/index.php
4. Fill Name + ID, click Submit -> row is saved in the "people" table.
5. Check it in phpMyAdmin -> simple_db -> people -> Browse tab.
