<?php
require_once "config.php";

$message = "";

// If the form was submitted, save it
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"]);
    $id   = trim($_POST["id"]);

    if ($name === "" || $id === "") {
        $message = "Name and ID are both required.";
    } else {
        $stmt = $conn->prepare("INSERT INTO people (name, id_number) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $id);
        $stmt->execute();
        $stmt->close();
        $message = "Saved successfully!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Simple Form</title>
</head>
<body>

    <h1>Simple Registration Form</h1>

    <?php if ($message): ?>
        <p><b><?php echo htmlspecialchars($message); ?></b></p>
    <?php endif; ?>

    <form method="POST">
        <label>Name:</label><br>
        <input type="text" name="name"><br><br>

        <label>ID:</label><br>
        <input type="text" name="id"><br><br>

        <button type="submit">Submit</button>
    </form>

</body>
</html>
