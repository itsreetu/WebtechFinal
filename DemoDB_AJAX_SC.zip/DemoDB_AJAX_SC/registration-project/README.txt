========================================================
 SIMPLE REGISTRATION FORM (HTML + PHP + MySQL + AJAX)
 Step-by-step setup guide (every click explained)
========================================================

WHAT THIS PROJECT DOES
-----------------------
- A registration form (Name, User ID, Email, Password)
- PHP validates the input on the server
- While typing, AJAX (JavaScript) checks the database and
  shows "Already exist" if the Name or User ID is already used
- On successful registration:
    - A SESSION is created (used by welcome.php)
    - A COOKIE is saved in the browser (remembers your name
      next time you open index.php)
- Data is stored in MySQL via phpMyAdmin

FILES INCLUDED
---------------
config.php      -> database connection settings
index.php       -> the registration form (with AJAX)
check_user.php  -> AJAX endpoint, checks if name/id exists
register.php    -> validates form + saves to database
welcome.php     -> page shown after successful registration
logout.php      -> destroys the session
database.sql    -> ready-made SQL to create the database/table


========================================================
 PART 1 - INSTALL A LOCAL SERVER (skip if already installed)
========================================================
You need a local server with PHP + MySQL + phpMyAdmin.
The easiest way is XAMPP (Windows/Mac/Linux):

1. Download XAMPP from https://www.apachefriends.org
2. Install it (keep all default options during install).
3. Open the "XAMPP Control Panel".
4. Click "Start" next to Apache.
5. Click "Start" next to MySQL.
   (Both rows should turn green.)


========================================================
 PART 2 - COPY THE PROJECT FILES
========================================================
1. Find your XAMPP installation folder.
   - Windows: C:\xampp\htdocs
   - Mac: /Applications/XAMPP/htdocs
2. Copy the WHOLE "registration-project" folder into "htdocs".
   Final path example: C:\xampp\htdocs\registration-project


========================================================
 PART 3 - CREATE THE DATABASE IN PHPMYADMIN (click by click)
========================================================
You have TWO options below. Pick Option A (fastest) OR
Option B (fully manual, if you want to see every click).

--------------------------------------------------------
OPTION A - Import the ready-made SQL file (fastest)
--------------------------------------------------------
1. Open your web browser.
2. Go to: http://localhost/phpmyadmin
3. On the left sidebar, click "New".
4. In the "Database name" box, type: registration_db
5. Leave collation as default, click "Create".
6. Click on "registration_db" in the left sidebar to open it.
7. Click the "Import" tab (top menu).
8. Click "Choose File" and select the "database.sql" file
   from the project folder.
9. Scroll down and click the "Go" button.
10. You should see a green success message.
    The "users" table is now created automatically.

--------------------------------------------------------
OPTION B - Create everything manually (step by step)
--------------------------------------------------------
1. Open your browser and go to: http://localhost/phpmyadmin
2. On the left sidebar, click "New".
3. Type the database name: registration_db
4. Click the "Create" button.
5. You are now inside the new (empty) database.
   Under "Create table", type:
       Name:    users
       Number of columns: 6
   Click "Go".
6. A table appears with 6 empty column rows. Fill them in
   EXACTLY like this (left to right: Name, Type, Length/Values,
   then checkboxes on the right):

   Row 1:
     Name: id
     Type: INT
     Length: (leave empty)
     Check the box under "A_I" (Auto Increment)
     Check the box under "PRIMARY" (Index -> Primary)

   Row 2:
     Name: full_name
     Type: VARCHAR
     Length: 100
     Null: not checked (required field)

   Row 3:
     Name: user_id
     Type: VARCHAR
     Length: 50
     Null: not checked
     Index: choose "UNIQUE" (so no two users can share an ID)

   Row 4:
     Name: email
     Type: VARCHAR
     Length: 100
     Null: not checked
     Index: choose "UNIQUE"

   Row 5:
     Name: password
     Type: VARCHAR
     Length: 255
     Null: not checked

   Row 6:
     Name: created_at
     Type: TIMESTAMP
     Default value: choose "CURRENT_TIMESTAMP"

7. Scroll down and click "Save".
8. Your table structure should now show 6 columns:
   id, full_name, user_id, email, password, created_at.

(Either option gives you the exact same result.)


========================================================
 PART 4 - RUN THE PROJECT
========================================================
1. Make sure Apache and MySQL are still running (green) in
   the XAMPP Control Panel.
2. Open your browser and go to:
   http://localhost/registration-project/index.php
3. Fill in the form and click Register.
4. Try registering with the SAME name or User ID again -
   you should see "Already exist" appear automatically
   (this is the AJAX check) before you even submit.


========================================================
 PART 5 - CHECK YOUR DATA IN PHPMYADMIN
========================================================
1. Go to http://localhost/phpmyadmin
2. Click "registration_db" on the left sidebar.
3. Click "users" table.
4. Click the "Browse" tab to see all registered rows.


========================================================
 TROUBLESHOOTING
========================================================
- "Database connection failed": open config.php and make sure
  $db_user, $db_pass match your MySQL login (default XAMPP is
  user "root" with an EMPTY password).
- Blank page: turn on PHP errors temporarily by adding this to
  the very top of config.php:
      ini_set('display_errors', 1);
      error_reporting(E_ALL);
- "Already exist" never shows: make sure Apache/MySQL are both
  running and that you copied ALL project files, including
  check_user.php, into the same folder.
