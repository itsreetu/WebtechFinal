<?php
// This file is called by AJAX (JavaScript) only.
// It checks the database and returns JSON like: {"exists":true,"message":"Already exist"}

header('Content-Type: application/json');
require_once "config.php";

$field = isset($_GET['field']) ? $_GET['field'] : "";
$value = isset($_GET['value']) ? trim($_GET['value']) : "";

// Only allow checking these two columns (security: whitelist)
$allowed_fields = ["full_name", "user_id"];

$response = ["exists" => false, "message" => ""];

if (in_array($field, $allowed_fields) && $value !== "") {

    // Prepared statement to avoid SQL injection
    $stmt = $conn->prepare("SELECT id FROM users WHERE $field = ? LIMIT 1");
    $stmt->bind_param("s", $value);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $response["exists"]  = true;
        $response["message"] = "Already exist";
    }

    $stmt->close();
}

echo json_encode($response);
$conn->close();
?>
