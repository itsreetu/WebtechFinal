<?php
// ============================================
// DATABASE CONNECTION SETTINGS
// Change these ONLY if your phpMyAdmin/MySQL
// login details are different.
// ============================================
$db_host = "localhost";
$db_user = "root";
$db_pass = "";          // default XAMPP/WAMP password is empty
$db_name = "registration_db";

// Create connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Make sure data is stored/read correctly
$conn->set_charset("utf8mb4");
?>
