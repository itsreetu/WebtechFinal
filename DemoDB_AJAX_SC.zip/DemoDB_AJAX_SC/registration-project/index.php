<?php
// Show a message coming back from register.php (if any) and read cookie
session_start();
$error = isset($_SESSION['form_error']) ? $_SESSION['form_error'] : "";
$old   = isset($_SESSION['old_input']) ? $_SESSION['old_input'] : [];
unset($_SESSION['form_error'], $_SESSION['old_input']);

$last_registered = isset($_COOKIE['last_registered_name']) ? $_COOKIE['last_registered_name'] : "";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Simple Registration Form</title>
</head>
<body>

    <h1>Registration Form</h1>

    <?php if ($last_registered): ?>
        <p>Welcome back! Last person registered from this browser was:
            <b><?php echo htmlspecialchars($last_registered); ?></b>
            (remembered using a cookie)
        </p>
    <?php endif; ?>

    <?php if ($error): ?>
        <p style="color:red;"><b>Error:</b> <?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form action="register.php" method="POST" id="regForm">

        <label>Full Name:</label><br>
        <input type="text" name="full_name" id="full_name"
               value="<?php echo isset($old['full_name']) ? htmlspecialchars($old['full_name']) : ''; ?>"><br>
        <span id="name_msg" style="color:red;"></span><br><br>

        <label>User ID (unique):</label><br>
        <input type="text" name="user_id" id="user_id"
               value="<?php echo isset($old['user_id']) ? htmlspecialchars($old['user_id']) : ''; ?>"><br>
        <span id="id_msg" style="color:red;"></span><br><br>

        <label>Email:</label><br>
        <input type="text" name="email" id="email"
               value="<?php echo isset($old['email']) ? htmlspecialchars($old['email']) : ''; ?>"><br><br>

        <label>Password:</label><br>
        <input type="password" name="password" id="password"><br><br>

        <button type="submit" id="submitBtn">Register</button>
    </form>

    <script>
    // AJAX duplicate check for Name and ID
    function checkField(fieldName, value, messageBoxId) {
        var box = document.getElementById(messageBoxId);
        if (value.trim() === "") {
            box.innerHTML = "";
            return;
        }

        var xhr = new XMLHttpRequest();
        xhr.open("GET", "check_user.php?field=" + fieldName + "&value=" + encodeURIComponent(value), true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                var response = JSON.parse(xhr.responseText);
                if (response.exists) {
                    box.innerHTML = response.message; // "Already exist"
                } else {
                    box.innerHTML = "";
                }
            }
        };
        xhr.send();
    }

    document.getElementById("full_name").addEventListener("blur", function () {
        checkField("full_name", this.value, "name_msg");
    });

    document.getElementById("user_id").addEventListener("blur", function () {
        checkField("user_id", this.value, "id_msg");
    });

    // Optional: stop submit if a duplicate message is currently showing
    document.getElementById("regForm").addEventListener("submit", function (e) {
        var nameMsg = document.getElementById("name_msg").innerHTML;
        var idMsg   = document.getElementById("id_msg").innerHTML;
        if (nameMsg !== "" || idMsg !== "") {
            alert("Please fix the highlighted fields before submitting.");
            e.preventDefault();
        }
    });
    </script>

</body>
</html>
