<?php
session_start();
$_SESSION = [];
session_destroy();
// Note: the "last_registered_name" cookie is NOT deleted here on purpose,
// so index.php can still greet the user by name.
header("Location: index.php");
exit();
?>
