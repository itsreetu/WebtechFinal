<?php
session_start();
require_once "config.php";

// Only allow POST requests
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit();
}

// ---------- Collect input ----------
$full_name = trim($_POST['full_name'] ?? "");
$user_id   = trim($_POST['user_id'] ?? "");
$email     = trim($_POST['email'] ?? "");
$password  = trim($_POST['password'] ?? "");

// Keep old input so the form can be re-filled if there's an error
$_SESSION['old_input'] = [
    "full_name" => $full_name,
    "user_id"   => $user_id,
    "email"     => $email
];

// ---------- Server-side validation ----------
$errors = [];

if ($full_name === "") {
    $errors[] = "Full name is required.";
} elseif (!preg_match("/^[a-zA-Z ]+$/", $full_name)) {
    $errors[] = "Full name may only contain letters and spaces.";
}

if ($user_id === "") {
    $errors[] = "User ID is required.";
} elseif (!preg_match("/^[a-zA-Z0-9]+$/", $user_id)) {
    $errors[] = "User ID may only contain letters and numbers.";
}

if ($email === "") {
    $errors[] = "Email is required.";
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Please enter a valid email address.";
}

if ($password === "") {
    $errors[] = "Password is required.";
} elseif (strlen($password) < 6) {
    $errors[] = "Password must be at least 6 characters.";
}

// ---------- Duplicate check (server-side, in case JS was skipped) ----------
if (empty($errors)) {
    $stmt = $conn->prepare("SELECT id FROM users WHERE full_name = ? OR user_id = ? OR email = ? LIMIT 1");
    $stmt->bind_param("sss", $full_name, $user_id, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "Already exist: name, ID or email is already registered.";
    }
    $stmt->close();
}

// ---------- If errors, go back to the form ----------
if (!empty($errors)) {
    $_SESSION['form_error'] = implode(" ", $errors);
    header("Location: index.php");
    exit();
}

// ---------- Save to database ----------
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO users (full_name, user_id, email, password) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $full_name, $user_id, $email, $hashed_password);

if ($stmt->execute()) {

    // ---------- SESSION: mark user as logged in ----------
    $_SESSION['user_logged_in'] = true;
    $_SESSION['user_name']      = $full_name;
    $_SESSION['user_id']        = $user_id;
    unset($_SESSION['old_input']);

    // ---------- COOKIE: remember last registered name for 30 days ----------
    setcookie("last_registered_name", $full_name, time() + (30 * 24 * 60 * 60), "/");

    header("Location: welcome.php");
    exit();

} else {
    $_SESSION['form_error'] = "Something went wrong. Please try again.";
    header("Location: index.php");
    exit();
}

$stmt->close();
$conn->close();
?>
