<?php
session_start();

// If nobody is logged in (session not set), send back to the form
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
</head>
<body>

    <h1>Registration Successful!</h1>

    <p>Welcome, <b><?php echo htmlspecialchars($_SESSION['user_name']); ?></b>!</p>
    <p>Your User ID: <b><?php echo htmlspecialchars($_SESSION['user_id']); ?></b></p>

    <p>
        (This page only shows because a PHP SESSION was created after you registered.
        A COOKIE named <b>last_registered_name</b> was also saved in your browser,
        which is why <i>index.php</i> will greet you by name even after you log out.)
    </p>

    <a href="logout.php">Logout (destroy session)</a>

</body>
</html>
